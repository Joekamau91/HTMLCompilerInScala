%identifys 4 pieces input
:-dynamic(fall16sched/4).

%list of courses
course(cosc455,
location(yr7800, 204),
time(t, 1100),
instructor(dehlinger)).

course(cosc455,
location(yr7800, 402),
time(r, 1100),
instructor(dehlinger)).

course(cosc612,
location(yr7800, 125),
time(w, 1900),
instructor(dehlinger)).

course(cosc465,
location(yr7800, 202),
time(t, 1230),
instructor(davani)).

course(cosc465,
location(yr7800, 202),
time(r, 1230),
instructor(davani)).

course(cosc439,
location(yr7800, 401),
time(m, 1900),
instructor(azadegan)).

course(cosc578,
location(yr7800, 202),
time(m, 1900),
instructor(zimand)).

course(cosc175,
location(yr7800, 205),
time(t, 1100),
instructor(taylor)).

course(cosc175,
location(yr7800, 205),
time(r, 1100),
instructor(taylor)).
