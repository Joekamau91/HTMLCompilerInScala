Methods avalible:
half(A,B,Dif,Barrow) = Half-Subtractor
onetotwo(A,IN,Out1,Out2) = 1-to-2 Line Decoder
twotofour(A,B,IN,Out1,Out2,Out3,Out4) = 2-to-4 Line Decoder
twoinput(A,X1,X2,X) = 2-Input Multiplexor 
fourinput(A,B,X1,X2,X3,X4,X) = 4-Input Multiplexor 

Call method to print full table or enter specific arguments