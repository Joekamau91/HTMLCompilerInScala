# COSC455-Project3-Zeller

---
A Prolog based project for Towson University’s programing languages course (COSC 455). It is a based off a series of prompts that required Prolog code to answer. It utilizes significant aspects of logical programing found within prolog.
