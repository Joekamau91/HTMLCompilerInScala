%generates posible suspects
suspects(Sus)

% The murderer hates boddy and is greedyim
murderer(Sus1)